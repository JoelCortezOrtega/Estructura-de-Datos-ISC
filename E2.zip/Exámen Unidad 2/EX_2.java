import java.util.Scanner;	

public class EX_2 
{
	static int PT (int potencia) 
	{
		if (potencia == 0) 
		{
			return 1;
		}
		if(potencia == 1)
		{
			return 2;
		}
		else
		{
			return  2*(PT(potencia-1));
		}
	}		

	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in);
		int Valor;

		System.out.println("\n\t\tEjercicio 2 del Examen Practico Unidad 2");
		System.out.print("\n\nIngrese el valor de la potencia: ");
		Valor = in.nextInt();
		System.out.print("\nResultado de 2 elevado a la potencia de " + Valor + ": " + PT(Valor));
		System.out.print("\n\n");
	}
}