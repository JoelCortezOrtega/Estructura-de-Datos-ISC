import java.util.Scanner;

public class EX_3
{	
	static double menu_recursivo(double opcion)
	{
		int Opcion, anch, numPass;
		Scanner in = new Scanner(System.in);

		System.out.print("\n\nPor favor ingrese la cantidad de migraciones que desea realizar: ");
		anch = in.nextInt();
		Pilas stack = new Pilas(anch);

		System.out.print("\n\n");
		System.out.println("\n\t\tEjercicio 3 del Examen Practico Unidad 2");
		System.out.print("\n1) Dar de alta una migracion.");
		System.out.print("\n2) Dar de baja una migracion.");
		System.out.print("\n3) Desplegar todas las migraciones realizadas.");
		System.out.print("\n4) Desplegar la migracion mas reciente.");
		System.out.print("\n5) Desplegar la migracion mas antigua.");
		System.out.print("\n6) Salida.");
		System.out.print("\nOpcion: ");
		Opcion = in.nextInt();

		if(Opcion == 6)
		{
			System.out.print("\n\nSalida del programa.");
			return Opcion;
		}
		if(Opcion == 5)
		{
			stack.Antiguo();
			return menu_recursivo(Opcion);
		}
		if(Opcion == 4)
		{
			stack.Reciente();
			return menu_recursivo(Opcion);
		}
		if(Opcion == 3)
		{
			stack.Imprimir();
			return menu_recursivo(Opcion);
		}
		if(Opcion == 2)
		{
			System.out.print("\n\n");
			System.out.print("\nDar de Baja una migracion");
			stack.Quitar();
			return menu_recursivo(Opcion);
		}
		if(Opcion == 1)
		{
			System.out.print("\n\n");
			System.out.print("\nDar de Alta una migracion");
			System.out.print("\nNumero de pasaporte: ");
			numPass = in.nextInt();
			stack.Agregar(numPass);
			return menu_recursivo(Opcion);
		}
		else
		{
			System.out.print("\n\n\n\t!Por favor ingrese una de las opciones!");
			return menu_recursivo(Opcion);
		}
	}	
	public static void main(String[] args) 
	{
		int OpcionInicial = 0;
		menu_recursivo(OpcionInicial);
		System.out.print("\n\n");
	}
}

class Pilas
	{
 		private int capacity;  //Capacidad del Arreglo
 		private int [] lista; 
 		private int baja = 0;	// Creación del arreglo y se le asigna su capacidad
 		private int top = -1; 	

 		public Pilas(int cap)
 		{	
 			capacity = cap;
 			lista = new int [capacity];
 		}

 		public void Agregar(int alta) 
 		{  
  			if (top < capacity - 1) 
  			{  
  		 		top++;  
   				lista[top] = alta;  
   				System.out.println("\n\nEl numero de pasaporte: " +  alta  + " ha sido agregado a la lista de migrantes!");  
  			} 
  			else 
  			{  
   				System.out.println("\n\n\nLa listada de migrantes esta llena!");  
  			}  
 		}
 		public void Quitar() 
 		{  
  			if (top >= 0)
  			{  
  				System.out.println("El numero de pasaporte: " +  lista[top]  + " ha sido eliminado de la lista de migrantes!");
  				baja = lista[top];
   				top--;   
  			} 
  			else 
  			{  
   				System.out.println("\n\n\nLa listada de migrantes esta vacia!");  
  			}  
 		}
 		public void Imprimir() 
 		{  
  			if (top >= 0) 
  			{  
   				System.out.println("Lista de migrantes");  
   				for (int i = 0; i <= top; i++) 
   				{  
    				System.out.println("\n\nNumero de pasaporte: " +  lista[i]); 
   				}  
  			}
  			else
  			{
  				System.out.println("\n\n\nLa listada de migrantes esta vacia!");
  			}
  		}
  		public void Reciente()
  		{
  			if(top >= 0)
  			{
  				 System.out.println("\n\nEl ultimo numero de pasaporte agregado fue: " +  lista[top]);
  			}
  			else
  			{
  				System.out.println("\n\n\nLa listada de migrantes esta vacia!");
  			}
  		}
  		public void Antiguo()
  		{
  			if(top >= 0)
  			{
  				 System.out.println("\n\nEl primer numero de pasaporte agregado fue: " +  lista[0]);
  			}
  			else
  			{
  				System.out.println("\n\n\nLa listada de migrantes esta vacia!");
  			}
  		}  
}