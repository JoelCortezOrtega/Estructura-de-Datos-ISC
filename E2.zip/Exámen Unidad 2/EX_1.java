import java.util.Scanner;	

public class EX_1 
{
	static int Sumatoria (int numero) 
	{
		if (numero == 9) 
		{
			return 9;
		}
		else
		{
			return  numero + Sumatoria (numero+1);
		}
	}		

	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in);
		int Valor = 1;

		System.out.println("\n\t\tEjercicio 1 del Examen Practico Unidad 2");
		System.out.println("\nResultado de la Sumatoria de los numeros del 1 al 9 es de: " + Sumatoria(Valor));;
	}
}